<?php
namespace PayPal\Test;

class Constants {
	const CLIENT_ID = 'EBWKjlELKMYqRNQ6sYvFo64FtaRLRR5BdHEESmha49TM';
	const CLIENT_SECRET = 'EO422dn3gQLgDbuwqTjzrFgFtaRLRR5BdHEESmha49TM';
}
